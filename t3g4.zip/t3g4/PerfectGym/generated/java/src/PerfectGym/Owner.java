package PerfectGym;

import java.util.*;
import org.overture.codegen.runtime.*;

@SuppressWarnings("all")
public class Owner extends User {
  public void cg_init_Owner_1(
      final String newName,
      final Number newAge,
      final Object newGender,
      final String newNationality) {

    cg_init_User_1(
        newName,
        PerfectGym.quotes.OwnerQuote.getInstance(),
        newAge,
        ((Object) newGender),
        newNationality);
  }

  public Owner(
      final String newName,
      final Number newAge,
      final Object newGender,
      final String newNationality) {

    cg_init_Owner_1(newName, newAge, newGender, newNationality);
  }

  public Owner() {}

  public String toString() {

    return "Owner{}";
  }
}
