package PerfectGym;

import java.util.*;
import org.overture.codegen.runtime.*;

@SuppressWarnings("all")
public class ClientTest extends MyTestCase {
  private Owner owner1 =
      new Owner("Rui", 21L, PerfectGym.quotes.MaleQuote.getInstance(), "portuguese");
  private Club club1 = new Club("Bombados", owner1, 17L);
  private Client client1 =
      new Client("Vasco", 25L, PerfectGym.quotes.MaleQuote.getInstance(), "brazilian");
  private Trainer trainer1 =
      new Trainer("Alex", 33L, PerfectGym.quotes.MaleQuote.getInstance(), "english");
  private Product product1 = new Product("Prota", 29.99, 40L);
  private GymClass gymClass1 =
      new GymClass(
          "Aula de baixa intensidade",
          "Pilates",
          trainer1,
          PerfectGym.quotes.TuesdayQuote.getInstance(),
          Utils.CreateHour(9L, 0L),
          Utils.CreateHour(10L, 0L),
          Utils.CreateDate(2019L, 1L, 11L));
  private GymFeePayment gymFeePayment1 =
      new GymFeePayment(client1, 80L, Utils.CreateDate(2019L, 1L, 22L), Utils.CreateHour(8L, 0L));
  private ProductPayment productPayment1 =
      new ProductPayment(
          client1, product1, 2L, Utils.CreateDate(2019L, 1L, 30L), Utils.CreateHour(18L, 29L));
  private PersonalTrainingPayment personalTrainingPayment1 =
      new PersonalTrainingPayment(
          client1, 30L, Utils.CreateDate(2019L, 1L, 23L), Utils.CreateHour(8L, 0L));

  public void Run() {

    IO.println("\nClient Tests");
    club1.addTrainer(trainer1, owner1);
    club1.addClient(client1, owner1);
    client1.addTrainer(trainer1, 30L);
    client1.addGymClass(gymClass1);
    client1.addGymAttendence(20191111L);
    assertEqual(trainer1, client1.getTrainer());
    assertEqual(30L, client1.getPersonalTrainingFee());
    assertEqual(SetUtil.set(gymClass1), client1.getClasses());
    assertEqual(SetUtil.set(20190111L, 20191111L), client1.getGymAttendences());
    IO.println("\nInitiate GetPayments");
    assertEqual(SetUtil.set(gymFeePayment1), client1.getGymFeePayments());
    assertEqual(SetUtil.set(productPayment1), client1.getProductPayments());
    assertEqual(SetUtil.set(personalTrainingPayment1), client1.getPersonalTrainingPayments());
    IO.println("\nInitiate RemovePayments");
    client1.removeGymFeePayment(gymFeePayment1);
    client1.removeProductPayment(productPayment1);
    client1.removePersonalTrainingPayment(personalTrainingPayment1);
    IO.println("\nInitiate GetHistoryPayments");
    assertEqual(SetUtil.set(gymFeePayment1), client1.getHistoryGymFeePayments());
    assertEqual(SetUtil.set(productPayment1), client1.getHistoryProductPayments());
    assertEqual(
        SetUtil.set(personalTrainingPayment1), client1.getHistoryPersonalTrainingPayments());
    IO.println("\nInitiate Products");
    client1.addProductBought(product1, 1L, 29.99);
    assertEqual(89.97, client1.getTotalSPentOnProducts());
    assertEqual(MapUtil.map(new Maplet("Prota", 3L)), client1.getProductsBought());
    IO.println("Finalizing Client Tests");
  }

  public ClientTest() {}

  public String toString() {

    return "ClientTest{"
        + "owner1 := "
        + Utils.toString(owner1)
        + ", club1 := "
        + Utils.toString(club1)
        + ", client1 := "
        + Utils.toString(client1)
        + ", trainer1 := "
        + Utils.toString(trainer1)
        + ", product1 := "
        + Utils.toString(product1)
        + ", gymClass1 := "
        + Utils.toString(gymClass1)
        + ", gymFeePayment1 := "
        + Utils.toString(gymFeePayment1)
        + ", productPayment1 := "
        + Utils.toString(productPayment1)
        + ", personalTrainingPayment1 := "
        + Utils.toString(personalTrainingPayment1)
        + "}";
  }
}
