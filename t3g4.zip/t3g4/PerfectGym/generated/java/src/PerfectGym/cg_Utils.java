package PerfectGym;

import java.util.*;
import org.overture.codegen.runtime.*;

@SuppressWarnings("all")
public class cg_Utils {
  public cg_Utils() {}

  public static Boolean IsValidDate(final Number y, final Number m, final Number d) {

    Boolean andResult_223 = false;

    if (y.longValue() >= 1L) {
      Boolean andResult_224 = false;

      if (m.longValue() >= 1L) {
        Boolean andResult_225 = false;

        if (m.longValue() <= 12L) {
          Boolean andResult_226 = false;

          if (d.longValue() >= 1L) {
            if (d.longValue() <= DaysOfMonth(y, m).longValue()) {
              andResult_226 = true;
            }
          }

          if (andResult_226) {
            andResult_225 = true;
          }
        }

        if (andResult_225) {
          andResult_224 = true;
        }
      }

      if (andResult_224) {
        andResult_223 = true;
      }
    }

    return andResult_223;
  }

  public static Boolean IsValidHour(final Number h, final Number m) {

    Boolean andResult_227 = false;

    if (h.longValue() >= 1L) {
      Boolean andResult_228 = false;

      if (h.longValue() <= 24L) {
        Boolean andResult_229 = false;

        if (m.longValue() >= 0L) {
          if (m.longValue() <= 60L) {
            andResult_229 = true;
          }
        }

        if (andResult_229) {
          andResult_228 = true;
        }
      }

      if (andResult_228) {
        andResult_227 = true;
      }
    }

    return andResult_227;
  }

  public static Boolean IsLeapYear(final Number year) {

    Boolean orResult_8 = false;

    Boolean andResult_230 = false;

    if (Utils.equals(Utils.mod(year.longValue(), 4L), 0L)) {
      if (!(Utils.equals(Utils.mod(year.longValue(), 100L), 0L))) {
        andResult_230 = true;
      }
    }

    if (andResult_230) {
      orResult_8 = true;
    } else {
      orResult_8 = Utils.equals(Utils.mod(year.longValue(), 400L), 0L);
    }

    return orResult_8;
  }

  public static Number DaysOfMonth(final Number y, final Number m) {

    Number casesExpResult_1 = null;

    Number intPattern_1 = m;
    Boolean success_5 = Utils.equals(intPattern_1, 1L);

    if (!(success_5)) {
      Number intPattern_2 = m;
      success_5 = Utils.equals(intPattern_2, 3L);

      if (!(success_5)) {
        Number intPattern_3 = m;
        success_5 = Utils.equals(intPattern_3, 5L);

        if (!(success_5)) {
          Number intPattern_4 = m;
          success_5 = Utils.equals(intPattern_4, 7L);

          if (!(success_5)) {
            Number intPattern_5 = m;
            success_5 = Utils.equals(intPattern_5, 8L);

            if (!(success_5)) {
              Number intPattern_6 = m;
              success_5 = Utils.equals(intPattern_6, 10L);

              if (!(success_5)) {
                Number intPattern_7 = m;
                success_5 = Utils.equals(intPattern_7, 12L);

                if (!(success_5)) {
                  Number intPattern_8 = m;
                  success_5 = Utils.equals(intPattern_8, 4L);

                  if (!(success_5)) {
                    Number intPattern_9 = m;
                    success_5 = Utils.equals(intPattern_9, 6L);

                    if (!(success_5)) {
                      Number intPattern_10 = m;
                      success_5 = Utils.equals(intPattern_10, 9L);

                      if (!(success_5)) {
                        Number intPattern_11 = m;
                        success_5 = Utils.equals(intPattern_11, 11L);

                        if (!(success_5)) {
                          Number intPattern_12 = m;
                          success_5 = Utils.equals(intPattern_12, 2L);

                          if (success_5) {
                            Number ternaryIfExp_1 = null;

                            if (IsLeapYear(y)) {
                              ternaryIfExp_1 = 29L;
                            } else {
                              ternaryIfExp_1 = 28L;
                            }

                            casesExpResult_1 = ternaryIfExp_1;
                          }

                        } else {
                          casesExpResult_1 = 30L;
                        }

                      } else {
                        casesExpResult_1 = 30L;
                      }

                    } else {
                      casesExpResult_1 = 30L;
                    }

                  } else {
                    casesExpResult_1 = 30L;
                  }

                } else {
                  casesExpResult_1 = 31L;
                }

              } else {
                casesExpResult_1 = 31L;
              }

            } else {
              casesExpResult_1 = 31L;
            }

          } else {
            casesExpResult_1 = 31L;
          }

        } else {
          casesExpResult_1 = 31L;
        }

      } else {
        casesExpResult_1 = 31L;
      }

    } else {
      casesExpResult_1 = 31L;
    }

    return casesExpResult_1;
  }

  public static Number CreateDate(final Number y, final Number m, final Number d) {

    return y.longValue() * 10000L + m.longValue() * 100L + d.longValue();
  }

  public static Number CreateHour(final Number h, final Number m) {

    return h.longValue() * 100L + m.longValue();
  }

  public static Number Year(final Number d) {

    return Utils.div(d.longValue(), 10000L);
  }

  public static Number Month(final Number d) {

    return Utils.mod(Utils.div(d.longValue(), 100L), 100L);
  }

  public static Number Day(final Number d) {

    return Utils.mod(d.longValue(), 100L);
  }

  public static Number Hours(final Number h) {

    return Utils.div(h.longValue(), 100L);
  }

  public static Number Minutes(final Number h) {

    return Utils.mod(h.longValue(), 100L);
  }

  public static Boolean overlaps(
      final Number startHour1,
      final Number endHour1,
      final Number startHour2,
      final Number endHour2) {

    Boolean orResult_9 = false;

    Boolean andResult_232 = false;

    if (startHour1.longValue() >= startHour2.longValue()) {
      if (startHour1.longValue() < endHour2.longValue()) {
        andResult_232 = true;
      }
    }

    if (andResult_232) {
      orResult_9 = true;
    } else {
      Boolean orResult_10 = false;

      Boolean andResult_233 = false;

      if (endHour1.longValue() > startHour2.longValue()) {
        if (endHour1.longValue() <= endHour2.longValue()) {
          andResult_233 = true;
        }
      }

      if (andResult_233) {
        orResult_10 = true;
      } else {
        Boolean andResult_234 = false;

        if (startHour1.longValue() <= startHour2.longValue()) {
          if (endHour1.longValue() >= endHour2.longValue()) {
            andResult_234 = true;
          }
        }

        orResult_10 = andResult_234;
      }

      orResult_9 = orResult_10;
    }

    return orResult_9;
  }

  public String toString() {

    return "cg_Utils{}";
  }
}
